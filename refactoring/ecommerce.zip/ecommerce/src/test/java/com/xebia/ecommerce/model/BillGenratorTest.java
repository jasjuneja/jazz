package com.xebia.ecommerce.model;

import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

public class BillGenratorTest extends TestCase {

	BillGenerator billgenerator = new BillGenerator();

	Map<String, Integer> item = null;
	Customer customer = null;

	@Before
	public void setUp() {

		item = new HashMap<String, Integer>();
		item.put("jeans", 110);
		item.put("soap", 10);

		customer = new Customer();
		customer.setCustomerlist(item);

	}

	@Test
	public void testgetBillValidInput() {
		customer.setType("store");
		assertEquals(87, billgenerator.getBill(customer));
	}

	@Test
	public void testgetBillInValidInput() {
		customer.setType("type");
		assertNotSame(87, billgenerator.getBill(customer));
	}

	@Test
	public void testCaluculateDiscount() {
		assertEquals(180, billgenerator.caluculateDiscount(200, 10));
	}

	@Test
	public void testTotalDiscount() {
		assertEquals(95, billgenerator.totalDiscount(100));
	}

	@Test
	public void testCalculateSumForCustomerYearGreaterThanOrEqualTwo() {
		assertEquals(115, billgenerator.calculateSum(item, 2));
	}

	@Test
	public void testCalculateSumForCustomerYearLesserThanOrEqualOne() {
		assertEquals(120, billgenerator.calculateSum(item, 1));
	}

	@Test
	public void testCalculateSumForStoreMember() {
		assertEquals(87, billgenerator.calculateSum(item, "store"));
	}

	@Test
	public void testCalculateSumForAffiliateMember() {
		assertEquals(109, new BillGenerator().calculateSum(item, "affiliate"));
	}
}
