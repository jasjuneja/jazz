package com.xebia.ecommerce;

import java.util.Map;
import java.util.Map.Entry;

import com.xebia.ecommerce.model.BillGenerator;
import com.xebia.ecommerce.model.Customer;
import com.xebia.ecommerce.model.CustomerType;
import com.xebia.ecommerce.model.Warehouse;

public class Home {

	public static void main(String[] args) throws InterruptedException {

		Customer customer = new Customer();
		Warehouse warehouse = Warehouse.getInstance();
		CustomerType customertype = CustomerType.getInstance();

		System.out.println("E-Commerce");
		Thread.sleep(2000);
		Map<String, Integer> itemlist = warehouse.getAllItems();

		for (Entry<String, Integer> item : itemlist.entrySet()) {
			System.out.println(item.getKey().toUpperCase() + " "
					+ item.getValue());
		}

		customer.generateUserList(itemlist);
		System.out.println("You Selected : ");
		for (Entry<String, Integer> item : customer.getItemlist().entrySet()) {
			System.out.println(item.getKey() + " " + item.getValue());
		}
		System.out.println("What Type Of Customer You Are ? : ");
		Thread.sleep(2000);

		Map<String, String> c = customertype.getCustomerList();
		for (Entry<String, String> item : c.entrySet()) {
			System.out.println(item.getKey().toUpperCase());
		}

		customer.type();
		new BillGenerator().getBill(customer);

	}

}
