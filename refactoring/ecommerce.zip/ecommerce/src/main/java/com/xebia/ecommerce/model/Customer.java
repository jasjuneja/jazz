package com.xebia.ecommerce.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Customer {

	private static Scanner s = null;
	private String type;

	private Map<String, Integer> customerlist;
	private Map<String, String> customertype;

	private int years;

	public Customer() {
		type = null;
		customerlist = new HashMap<String, Integer>();
		customertype = CustomerType.getInstance().getCustomerList();
		years = 0;
		s = new Scanner(System.in);
	}

	public String getType() {
		return type;
	}

	public void type() {

		while (true) {
			System.out.print("Enter Type : ");
			String ctype = s.next();
			if (null != customertype.get(ctype)) {
				if (ctype.equalsIgnoreCase("other")) {
					System.out.print("Enter Years : ");
					setYears(s.nextInt());
				}
				setType(ctype);
				break;
			} else {
				System.out.println("!Member");
			}
		}

	}

	public void setType(String type) {
		this.type = type;
	}

	public Map<String, Integer> getItemlist() {
		return customerlist;
	}

	public Map<String, Integer> getCustomerlist() {
		return customerlist;
	}

	public void setCustomerlist(Map<String, Integer> customerlist) {
		this.customerlist = customerlist;
	}

	private void addToCart(String item, int rate) {
		customerlist.put(item, rate);
	}

	public int getYears() {
		return years;
	}

	public void setYears(int years) {
		this.years = years;
	}

	public Integer getItem(String item) {
		return customerlist.get(item);
	}

	public void generateUserList(Map<String, Integer> itemlist) {

		while (true) {
			System.out.print("Enter Item Name : ");
			String item = s.next().toLowerCase();

			if (itemlist.containsKey(item)) {
				if (null != getItem(item)) {
					addToCart(item, getItem(item) + itemlist.get(item));
				} else {
					addToCart(item, itemlist.get(item));
				}
			}
			System.out.print("Continue Shopping...(y/n) : ");
			if (s.next().equalsIgnoreCase("n")) {
				break;
			}
		}

	}

}
