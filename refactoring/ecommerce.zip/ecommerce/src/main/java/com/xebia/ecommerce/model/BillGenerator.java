package com.xebia.ecommerce.model;

import java.util.Map;
import java.util.Map.Entry;

public class BillGenerator {

	Warehouse warehouse = null;
	CustomerType customertype = null;

	public BillGenerator() {
		warehouse = Warehouse.getInstance();
		customertype = CustomerType.getInstance();
	}

	public int getBill(Customer customer) {

		int sum = 0;
		if (customer.getType().equalsIgnoreCase("other")) {

			sum = calculateSum(customer.getItemlist(), customer.getYears());
			System.out.println("Total Sum After Customer Based Discount : "
					+ sum);
		} else {
			sum = calculateSum(customer.getItemlist(), customer.getType());
			System.out.println("Total Sum After Customer Based Discount : "
					+ sum);
		}
		int totalSum = totalDiscount(sum);
		System.out.println("You Pay After Discount On Bill Amount : "
				+ totalSum);

		return totalSum;

	}

	int caluculateDiscount(int sum, int discount) {
		int result = 0;
		result = sum - (sum * discount) / 100;
		return result;
	}

	int totalDiscount(int sum) {
		int totaldiscount = sum / 100;
		sum = sum - (totaldiscount * 5);
		System.out.println("Discount On Bill Amount : " + (totaldiscount * 5));
		return sum;
	}

	int calculateSum(Map<String, Integer> items, int year) {

		int sum1 = 0;
		int sum2 = 0;

		for (Entry<String, Integer> item : items.entrySet()) {

			if (!warehouse.isGrocery(item.getKey())) {
				System.out.println("Non Grocery Item : " + item.getKey());
				sum1 = sum1 + item.getValue();
			} else {
				sum2 = sum2 + item.getValue();
				System.out.println("Grocery Item : " + item.getKey());
			}
		}

		System.out.println("Non Grocery Item Total : " + sum1);
		System.out.println("Grocery Item Total : " + sum2);

		if (2 <= year) {
			int discount = customertype.getDiscount("other");
			sum1 = caluculateDiscount(sum1, discount);
			System.out.println("After " + discount
					+ "% On Non Grocery Items Sum : " + sum1);
			System.out.println("Sum Of Grocery Item(No Discount On Grocery): "
					+ sum2);
		} else {
			System.out.println("No Discount For Less Then 1 Year Customer");
		}

		return sum1 + sum2;
	}

	int calculateSum(Map<String, Integer> items, String type) {

		int sum1 = 0;
		int sum2 = 0;

		for (Entry<String, Integer> item : items.entrySet()) {
			if (!warehouse.isGrocery(item.getKey())) {
				System.out.println("Non Grocery Item : " + item.getKey());
				sum1 = sum1 + item.getValue();
			} else {
				sum2 = sum2 + item.getValue();
				System.out.println("Grocery Item : " + item.getKey());
			}
		}

		System.out.println("Non Grocery Item Total : " + sum1);
		System.out.println("Grocery Item Total : " + sum2);
		int discount = customertype.getDiscount(type);
		sum1 = caluculateDiscount(sum1, discount);
		System.out.println("After " + discount
				+ "% On Non Grocery Items Sum : " + sum1);
		System.out.println("Sum Of Grocery Item(No Discount On Grocery): "
				+ sum2);

		return sum1 + sum2;
	}

}