package com.xebia.ecommerce.model;

import java.util.HashMap;
import java.util.Map;

public class CustomerType {

	private Map<String, String> customer = null;
	private static boolean isinstance = false;
	private static CustomerType type = null;

	private CustomerType() {
		customer = new HashMap<String, String>();
		customer.put("store", "30");
		customer.put("affiliate", "10");
		customer.put("other", "5");
	}

	public static CustomerType getInstance() {

		if (!isinstance) {
			type = new CustomerType();
			isinstance = true;
		}
		return type;

	}

	public Map<String, String> getCustomerList() {
		return customer;
	}

	public int getDiscount(String type) {

		int result = 0;
		if (null != customer.get(type)) {
			result = Integer.parseInt(customer.get(type));
		}
		return result;
	}

}
