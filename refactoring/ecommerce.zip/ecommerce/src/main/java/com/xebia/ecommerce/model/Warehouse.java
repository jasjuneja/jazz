package com.xebia.ecommerce.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Warehouse {

	private ArrayList<String> grocerylist = null;
	private Map<String, Integer> itemlist = null;
	static boolean isinstance = false;
	private static Warehouse instance = null;

	private Warehouse() {
		grocerylist = new ArrayList<String>();
		grocerylist.add("deodrant");
		grocerylist.add("soap");
		grocerylist.add("bread");
		grocerylist.add("biscuits");

		itemlist = new HashMap<String, Integer>();
		itemlist.put("deodrant", 12);
		itemlist.put("jeans", 110);
		itemlist.put("shirt", 15);
		itemlist.put("soap", 10);

	}

	public static Warehouse getInstance() {
		if (!isinstance) {
			instance = new Warehouse();
			isinstance = true;
		}
		return instance;
	}

	public boolean isGrocery(String item) {
		boolean result = false;
		result = grocerylist.contains(item);
		return result;
	}

	public Map<String, Integer> getAllItems() {
		return itemlist;
	}

	public Integer getItem(Integer key) {
		return itemlist.get(key);
	}

}
